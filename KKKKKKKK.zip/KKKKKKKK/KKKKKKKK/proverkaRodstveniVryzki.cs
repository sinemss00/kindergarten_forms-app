﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKKKKKKK
{
    public partial class proverkaRodstveniVryzki : Form
    {
        List<Dete> rodstveniList = new List<Dete>();
        public proverkaRodstveniVryzki(List<Dete> list)
        {
            InitializeComponent();
            rodstveniList = list;
            dataGridView1.DataSource = Form1.deteList;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataGridViewRow selected = dataGridView1.CurrentRow;

            if (selected != null && !selected.IsNewRow)
            {
                string roditel1 = selected.Cells[2].Value?.ToString().ToLower();
                string roditel2 = selected.Cells[3].Value?.ToString().ToLower();
                string imeIzbrano = selected.Cells[1].Value?.ToString();

                List<string> decaSushtiRoditeli = new List<string>();

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row == null || row.IsNewRow) continue;

                    string rod1 = row.Cells[2].Value?.ToString().ToLower();
                    string rod2 = row.Cells[3].Value?.ToString().ToLower();
                    string ime = row.Cells[1].Value?.ToString();

                    if (string.IsNullOrEmpty(rod1) || string.IsNullOrEmpty(rod2) || string.IsNullOrEmpty(ime))
                        continue;

                    if ((rod1 == roditel1 && rod2 == roditel2) || (rod1 == roditel2 && rod2 == roditel1))
                    {
                        if (!decaSushtiRoditeli.Contains(ime))
                        {
                            decaSushtiRoditeli.Add(ime);
                        }
                    }
                }

                decaSushtiRoditeli.Remove(imeIzbrano);
                listBox1.Items.Clear();

                if (decaSushtiRoditeli.Count > 0)
                {
                    listBox1.Items.Add("Децата, които имат общи родители са:");
                    listBox1.Items.Add(imeIzbrano);
                    foreach (string ime in decaSushtiRoditeli)
                    {
                        listBox1.Items.Add(ime);
                    }
                }
                else
                {
                    listBox1.Items.Add("Детето няма братя и сестри.");
                }
            }
        }
    }
}
