﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace KKKKKKKK
{
    public partial class drugi : Form
    {
        List<Dete> deteList;
        public drugi(List<Dete> deteList)
        {
            InitializeComponent();
            this.deteList = deteList;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dete result = deteList.Find(dete => dete.Egn == textBox1.Text);
            if (result != null)
            {
                MessageBox.Show("Дете с това ЕГН съществува!");
                textBox1.Text = "";
                return;
            }
            FileStream fs = new FileStream(Form1.FN, FileMode.OpenOrCreate);
            StreamWriter sw = new StreamWriter(fs);
            Dete d = new Dete(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, comboBox1.Text, comboBox2.Text);
            deteList.Add(d);
            foreach (Dete dete in deteList)
            {
                sw.WriteLine(dete.DescribeForFile());

            }
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();

            sw.Close();
            fs.Close();

            MessageBox.Show("Данните за детето са успешно запазени във файл.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string egnZaIztrivane = textBox1.Text;

            if (string.IsNullOrWhiteSpace(egnZaIztrivane))
            {
                MessageBox.Show("Моля, въведете ЕГН на детето, което искате да изтриете.");
                return;
            }

            Dete zaIztrivane = null;

            foreach (Dete dete in deteList)
            {
                if (dete.Egn == egnZaIztrivane)
                {
                    zaIztrivane = dete;
                    break;
                }
            }

            if (zaIztrivane == null)
            {
                MessageBox.Show("Дете с това ЕГН не е намерено.");
                return;
            }

            DialogResult rezultat = MessageBox.Show("Наистина ли искате да се изтрие?", "Изтриване", MessageBoxButtons.OKCancel);

            if (rezultat == DialogResult.OK)
            {
                deteList.Remove(zaIztrivane);

                FileStream fs = new FileStream(Form1.FN, FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);

                foreach (Dete dete in deteList)
                {
                    sw.WriteLine(dete.DescribeForFile());
                }

                sw.Close();
                fs.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();

                MessageBox.Show("Данните са изтрити успешно.");
            }
        }

        private void drugi_Load(object sender, EventArgs e)
        {

        }
    }
}
