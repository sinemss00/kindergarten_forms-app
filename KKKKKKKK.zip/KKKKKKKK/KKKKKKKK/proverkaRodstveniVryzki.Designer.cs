﻿namespace KKKKKKKK
{
    partial class proverkaRodstveniVryzki
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(proverkaRodstveniVryzki));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.egnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roditel1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roditel2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.polDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prietoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vuzrastDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.egnDataGridViewTextBoxColumn,
            this.imeDataGridViewTextBoxColumn,
            this.roditel1DataGridViewTextBoxColumn,
            this.roditel2DataGridViewTextBoxColumn,
            this.polDataGridViewTextBoxColumn,
            this.prietoDataGridViewTextBoxColumn,
            this.vuzrastDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 36);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(945, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // egnDataGridViewTextBoxColumn
            // 
            this.egnDataGridViewTextBoxColumn.DataPropertyName = "Egn";
            this.egnDataGridViewTextBoxColumn.HeaderText = "Egn";
            this.egnDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.egnDataGridViewTextBoxColumn.Name = "egnDataGridViewTextBoxColumn";
            this.egnDataGridViewTextBoxColumn.Width = 125;
            // 
            // imeDataGridViewTextBoxColumn
            // 
            this.imeDataGridViewTextBoxColumn.DataPropertyName = "Ime";
            this.imeDataGridViewTextBoxColumn.HeaderText = "Ime";
            this.imeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.imeDataGridViewTextBoxColumn.Name = "imeDataGridViewTextBoxColumn";
            this.imeDataGridViewTextBoxColumn.Width = 125;
            // 
            // roditel1DataGridViewTextBoxColumn
            // 
            this.roditel1DataGridViewTextBoxColumn.DataPropertyName = "Roditel1";
            this.roditel1DataGridViewTextBoxColumn.HeaderText = "Roditel1";
            this.roditel1DataGridViewTextBoxColumn.MinimumWidth = 6;
            this.roditel1DataGridViewTextBoxColumn.Name = "roditel1DataGridViewTextBoxColumn";
            this.roditel1DataGridViewTextBoxColumn.Width = 125;
            // 
            // roditel2DataGridViewTextBoxColumn
            // 
            this.roditel2DataGridViewTextBoxColumn.DataPropertyName = "Roditel2";
            this.roditel2DataGridViewTextBoxColumn.HeaderText = "Roditel2";
            this.roditel2DataGridViewTextBoxColumn.MinimumWidth = 6;
            this.roditel2DataGridViewTextBoxColumn.Name = "roditel2DataGridViewTextBoxColumn";
            this.roditel2DataGridViewTextBoxColumn.Width = 125;
            // 
            // polDataGridViewTextBoxColumn
            // 
            this.polDataGridViewTextBoxColumn.DataPropertyName = "Pol";
            this.polDataGridViewTextBoxColumn.HeaderText = "Pol";
            this.polDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.polDataGridViewTextBoxColumn.Name = "polDataGridViewTextBoxColumn";
            this.polDataGridViewTextBoxColumn.Width = 125;
            // 
            // prietoDataGridViewTextBoxColumn
            // 
            this.prietoDataGridViewTextBoxColumn.DataPropertyName = "Prieto";
            this.prietoDataGridViewTextBoxColumn.HeaderText = "Prieto";
            this.prietoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.prietoDataGridViewTextBoxColumn.Name = "prietoDataGridViewTextBoxColumn";
            this.prietoDataGridViewTextBoxColumn.Width = 125;
            // 
            // vuzrastDataGridViewTextBoxColumn
            // 
            this.vuzrastDataGridViewTextBoxColumn.DataPropertyName = "Vuzrast";
            this.vuzrastDataGridViewTextBoxColumn.HeaderText = "Vuzrast";
            this.vuzrastDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.vuzrastDataGridViewTextBoxColumn.Name = "vuzrastDataGridViewTextBoxColumn";
            this.vuzrastDataGridViewTextBoxColumn.ReadOnly = true;
            this.vuzrastDataGridViewTextBoxColumn.Width = 125;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = typeof(KKKKKKKK.Dete);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Purple;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(564, 212);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 33);
            this.button1.TabIndex = 1;
            this.button1.Text = "Покажи";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(12, 273);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(690, 84);
            this.listBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(12, 212);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(512, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Натиснете бутона, за да видите децата с общи родители";
            // 
            // proverkaRodstveniVryzki
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1275, 678);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "proverkaRodstveniVryzki";
            this.Text = "proverkaRodstveniVryzki";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn egnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roditel1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roditel2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn polDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prietoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vuzrastDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Label label1;
    }
}