﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKKKKKKK
{
    public class Dete
    {
        public string Egn { get; set; }
        public string Ime { get; set; }
        public string Roditel1 { get; set; }
        public string Roditel2 { get; set; }

        private string pol;
        public string Pol
        {
            get { return pol; }
            set
            {
                string lower = value.ToLower();
                if (lower == "muj" || lower == "m")
                {
                    pol = "muj";
                }
                else if (lower == "jena" || lower == "j")
                {
                    pol = "jena";
                }
                else
                {
                    throw new ArgumentException("Nevalidna stoinost za pol. Tryabva da e 'muj' ili 'jena'!");
                }
            }
        }
        

        private string prieto;
        public string Prieto
        {
            get { return prieto; }
            set
            {
                string lower = value.ToLower();
                if (lower == "da")
                {
                    prieto = "da";
                }
                else if (lower == "ne")
                {
                    prieto = "ne";
                }
                else
                {
                    throw new ArgumentException("Nevalidna stoinost. Tryabva da e 'da' ili 'ne'!");
                }
            }
        }

        public Dete() { }

        public Dete(string egn, string ime, string roditel1, string roditel2, string pol, string prieto)
        {
            Egn = egn;
            Ime = ime;
            Roditel1 = roditel1;
            Roditel2 = roditel2;
            Pol = pol;
            Prieto = prieto;
        }

        public string DescribeForFile()
        {
            return $"{Egn};{Ime};{Roditel1};{Roditel2};{Pol};{Prieto}";
        }

        public static Dete ConvertFromFile(string red)
        {
            string[] elementi = red.Split(';');
            return new Dete(elementi[0], elementi[1], elementi[2], elementi[3], elementi[4], elementi[5]);
        }
        public int Vuzrast
        {
            get
            {
                if (string.IsNullOrEmpty(Egn) || Egn.Length != 10)
                    return 0;

                int year = int.Parse(Egn.Substring(0, 2));
                int month = int.Parse(Egn.Substring(2, 2));
                int day = int.Parse(Egn.Substring(4, 2));

                if (month >= 1 && month <= 12)
                {
                    year += 1900;
                }
                else if (month >= 21 && month <= 32)
                {
                    month -= 20;
                    year += 1800;
                }
                else if (month >= 41 && month <= 52)
                {
                    month -= 40;
                    year += 2000;
                }
                else
                {
                    return 0;
                }

                try
                {
                    DateTime birthDate = new DateTime(year, month, day);
                    DateTime today = DateTime.Today;
                    int age = today.Year - birthDate.Year;

                    if (today.Month < birthDate.Month || (today.Month == birthDate.Month && today.Day < birthDate.Day))
                    {
                        age--;
                    }

                    return age;
                }
                catch
                {
                    return 0;
                }
            }
        }
    }
}
