﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKKKKKKK
{
    public partial class proverkaPrieti : Form
    {
        private List<Dete> prietiList;
        public proverkaPrieti(List<Dete> list)
        {
            InitializeComponent();
            prietiList = list;
            dataGridView1.DataSource = Form1.deteList;
        }

        private void proverkaPrieti_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            DataGridViewRow selected = dataGridView1.CurrentRow;

            if (selected != null && !selected.IsNewRow)
            {
                string roditel1 = selected.Cells[2].Value?.ToString().Trim().ToLower();
                string roditel2 = selected.Cells[3].Value?.ToString().Trim().ToLower();
                string imeIzbrano = selected.Cells[1].Value?.ToString();

                if (string.IsNullOrEmpty(roditel1) || string.IsNullOrEmpty(roditel2)) return;

                List<string> bratqSestri = new List<string>();

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row == null || row.IsNewRow) continue;

                    string rod1 = row.Cells[2].Value?.ToString().ToLower();
                    string rod2 = row.Cells[3].Value?.ToString().ToLower();
                    string ime = row.Cells[1].Value?.ToString();
                    string prietoValue = row.Cells[5].Value?.ToString().ToLower();

                    if (string.IsNullOrEmpty(rod1) || string.IsNullOrEmpty(rod2) || string.IsNullOrEmpty(ime) || string.IsNullOrEmpty(prietoValue))
                        continue;

                    bool saSustiteRoditeli =
                        (rod1 == roditel1 && rod2 == roditel2) ||
                        (rod1 == roditel2 && rod2 == roditel1);

                    if (saSustiteRoditeli && prietoValue == "da" && ime != imeIzbrano && !bratqSestri.Contains(ime))
                    {
                        bratqSestri.Add(ime);
                    }
                }

                if (bratqSestri.Count > 0)
                {
                    listBox1.Items.Add("Детето има приети братя/сестри и те са:");
                    foreach (string ime in bratqSestri)
                    {
                        listBox1.Items.Add(ime);
                    }
                }
                else
                {
                    listBox1.Items.Add("Детето няма приети братя/сестри.");
                }
            }
        }
    }
}