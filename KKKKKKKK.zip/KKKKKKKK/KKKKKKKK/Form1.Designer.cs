﻿namespace KKKKKKKK
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.proverkaRodstveniVryzkiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proverkaPrietiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drugiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.egnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roditel1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roditel2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.polDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prietoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vuzrastDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.proverkaRodstveniVryzkiToolStripMenuItem,
            this.proverkaPrietiToolStripMenuItem,
            this.drugiToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(10, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1785, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // proverkaRodstveniVryzkiToolStripMenuItem
            // 
            this.proverkaRodstveniVryzkiToolStripMenuItem.Name = "proverkaRodstveniVryzkiToolStripMenuItem";
            this.proverkaRodstveniVryzkiToolStripMenuItem.Size = new System.Drawing.Size(241, 24);
            this.proverkaRodstveniVryzkiToolStripMenuItem.Text = "Проверка за родствени връзки";
            this.proverkaRodstveniVryzkiToolStripMenuItem.Click += new System.EventHandler(this.proverkaRodstveniVryzkiToolStripMenuItem_Click);
            // 
            // proverkaPrietiToolStripMenuItem
            // 
            this.proverkaPrietiToolStripMenuItem.Name = "proverkaPrietiToolStripMenuItem";
            this.proverkaPrietiToolStripMenuItem.Size = new System.Drawing.Size(171, 24);
            this.proverkaPrietiToolStripMenuItem.Text = "Приети братя/сестри";
            this.proverkaPrietiToolStripMenuItem.Click += new System.EventHandler(this.proverkaPrietiToolStripMenuItem_Click);
            // 
            // drugiToolStripMenuItem
            // 
            this.drugiToolStripMenuItem.Name = "drugiToolStripMenuItem";
            this.drugiToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.drugiToolStripMenuItem.Text = "Файл";
            this.drugiToolStripMenuItem.Click += new System.EventHandler(this.drugiToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.Purple;
            this.button1.Location = new System.Drawing.Point(395, 574);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(368, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "Покажи децата на избраната възраст";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(639, 527);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(124, 27);
            this.textBox1.TabIndex = 2;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(897, 527);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(589, 104);
            this.listBox1.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Thistle;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.egnDataGridViewTextBoxColumn,
            this.imeDataGridViewTextBoxColumn,
            this.roditel1DataGridViewTextBoxColumn,
            this.roditel2DataGridViewTextBoxColumn,
            this.polDataGridViewTextBoxColumn,
            this.prietoDataGridViewTextBoxColumn,
            this.vuzrastDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(326, 274);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1160, 215);
            this.dataGridView1.TabIndex = 4;
            // 
            // egnDataGridViewTextBoxColumn
            // 
            this.egnDataGridViewTextBoxColumn.DataPropertyName = "Egn";
            this.egnDataGridViewTextBoxColumn.HeaderText = "Egn";
            this.egnDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.egnDataGridViewTextBoxColumn.Name = "egnDataGridViewTextBoxColumn";
            this.egnDataGridViewTextBoxColumn.Width = 125;
            // 
            // imeDataGridViewTextBoxColumn
            // 
            this.imeDataGridViewTextBoxColumn.DataPropertyName = "Ime";
            this.imeDataGridViewTextBoxColumn.HeaderText = "Ime";
            this.imeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.imeDataGridViewTextBoxColumn.Name = "imeDataGridViewTextBoxColumn";
            this.imeDataGridViewTextBoxColumn.Width = 125;
            // 
            // roditel1DataGridViewTextBoxColumn
            // 
            this.roditel1DataGridViewTextBoxColumn.DataPropertyName = "Roditel1";
            this.roditel1DataGridViewTextBoxColumn.HeaderText = "Roditel1";
            this.roditel1DataGridViewTextBoxColumn.MinimumWidth = 6;
            this.roditel1DataGridViewTextBoxColumn.Name = "roditel1DataGridViewTextBoxColumn";
            this.roditel1DataGridViewTextBoxColumn.Width = 125;
            // 
            // roditel2DataGridViewTextBoxColumn
            // 
            this.roditel2DataGridViewTextBoxColumn.DataPropertyName = "Roditel2";
            this.roditel2DataGridViewTextBoxColumn.HeaderText = "Roditel2";
            this.roditel2DataGridViewTextBoxColumn.MinimumWidth = 6;
            this.roditel2DataGridViewTextBoxColumn.Name = "roditel2DataGridViewTextBoxColumn";
            this.roditel2DataGridViewTextBoxColumn.Width = 125;
            // 
            // polDataGridViewTextBoxColumn
            // 
            this.polDataGridViewTextBoxColumn.DataPropertyName = "Pol";
            this.polDataGridViewTextBoxColumn.HeaderText = "Pol";
            this.polDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.polDataGridViewTextBoxColumn.Name = "polDataGridViewTextBoxColumn";
            this.polDataGridViewTextBoxColumn.Width = 125;
            // 
            // prietoDataGridViewTextBoxColumn
            // 
            this.prietoDataGridViewTextBoxColumn.DataPropertyName = "Prieto";
            this.prietoDataGridViewTextBoxColumn.HeaderText = "Prieto";
            this.prietoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.prietoDataGridViewTextBoxColumn.Name = "prietoDataGridViewTextBoxColumn";
            this.prietoDataGridViewTextBoxColumn.Width = 125;
            // 
            // vuzrastDataGridViewTextBoxColumn
            // 
            this.vuzrastDataGridViewTextBoxColumn.DataPropertyName = "Vuzrast";
            this.vuzrastDataGridViewTextBoxColumn.HeaderText = "Vuzrast";
            this.vuzrastDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.vuzrastDataGridViewTextBoxColumn.Name = "vuzrastDataGridViewTextBoxColumn";
            this.vuzrastDataGridViewTextBoxColumn.ReadOnly = true;
            this.vuzrastDataGridViewTextBoxColumn.Width = 125;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = typeof(KKKKKKKK.Dete);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(402, 529);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Въведете възраст:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Plum;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Purple;
            this.label2.Location = new System.Drawing.Point(525, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(614, 31);
            this.label2.TabIndex = 6;
            this.label2.Text = "Целодневна детска градина \"Вълшебно детство\"";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Purple;
            this.label3.Location = new System.Drawing.Point(716, 211);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(342, 29);
            this.label3.TabIndex = 7;
            this.label3.Text = "Въведете данни за децата:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Plum;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1785, 791);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem proverkaRodstveniVryzkiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem proverkaPrietiToolStripMenuItem;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn egnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roditel1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roditel2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn polDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prietoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vuzrastDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem drugiToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

