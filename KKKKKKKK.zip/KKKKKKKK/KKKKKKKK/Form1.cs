﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKKKKKKK
{
    public partial class Form1 : Form
    {
        public static string FN = "D:\\126000\\deca5.txt";
        public static List<Dete> deteList = new List<Dete>();
        FileStream fs;
        public Form1()
        {
            InitializeComponent();
            if (File.Exists(FN))
            {
                fs = new FileStream(FN, FileMode.OpenOrCreate, FileAccess.Read);
                StreamReader sr = new StreamReader(fs);
                string line;

                while ((line = sr.ReadLine()) != null)
                {
                    if (!string.IsNullOrEmpty(line))
                    {
                        deteList.Add(Dete.ConvertFromFile(line));
                    }
                }
                fs.Close();
                sr.Close();

            }
            else
            {
                fs = new FileStream(FN, FileMode.Create);
                fs.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void proverkaRodstveniVryzkiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new proverkaRodstveniVryzki(deteList).ShowDialog();
        }

        private void proverkaPrietiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new proverkaPrieti(deteList).ShowDialog();
        }
        private void button1_Click(object sender, EventArgs e)
        {

            listBox1.Items.Clear();
            int oprVuzrast = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.IsNewRow) continue;

                string egn = row.Cells[0].Value?.ToString();
                if (deteList.Any(d => d.Egn == egn))
                    continue;
                //string egn = row.Cells[0].Value?.ToString();
                string ime = row.Cells[1].Value?.ToString();
                string roditel1 = row.Cells[2].Value?.ToString();
                string roditel2 = row.Cells[3].Value?.ToString();
                string pol = row.Cells[4].Value?.ToString();
                string prieto = row.Cells[5].Value?.ToString();

                if (string.IsNullOrWhiteSpace(egn) || string.IsNullOrWhiteSpace(ime))
                    continue;

                Dete dete = new Dete(egn, ime, roditel1, roditel2, pol, prieto);
                deteList.Add(dete);
                
            }

            if (int.TryParse(textBox1.Text, out oprVuzrast) && oprVuzrast > 0)
            {
                bool imaDeca = false;

                foreach (Dete d in deteList)
                {
                    if (d.Vuzrast == oprVuzrast)
                    {
                        listBox1.Items.Add($"Децата на {oprVuzrast} години са: {d.Ime}.");
                        imaDeca = true;
                    }
                }

                if (!imaDeca)
                {
                    listBox1.Items.Add("Няма деца на тази възраст! Въведете друга възраст!");
                }
            }
            else
            {
                MessageBox.Show("Моля, въведете валидна възраст!");
            }
        }

        private void drugiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new drugi(deteList).ShowDialog();
        }
    }
}